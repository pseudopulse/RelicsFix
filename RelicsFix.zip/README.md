# RelicsFix

Patches Forgotten Relics to make it work after AC. Requires you actually have Forgotten Relics installed.

# Changelog
## 1.0.1
- fixed bug with dry basin and slumbering satellite failing to spawn interactables if visited once, starting a new run, and visiting them again without seeing either abandoned aqueduct or sky meadows in the current session
## 1.0.0
- exists